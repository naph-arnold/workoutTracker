/* global use, db */
// MongoDB Playground
// To disable this template go to Settings | MongoDB | Use Default Template For Playground.
// Make sure you are connected to enable completions and to be able to run a playground.
// Use Ctrl+Space inside a snippet or a string literal to trigger completions.
// The result of the last command run in a playground is shown on the results panel.
// By default the first 20 documents will be returned with a cursor.
// Use 'console.log()' to print to the debug output.
// For more documentation on playgrounds please refer to
// https://www.mongodb.com/docs/mongodb-vscode/playgrounds/

// MongoDB Playground for "Workout Tracker" App
use('WorkoutTrackerDB');

// Insert sample workouts into the "workouts" collection
db.getCollection('workouts').insertMany([
  { name: 'Morning Yoga', type: 'Yoga', duration: 30, intensity: 'Low', date: new Date('2021-07-14') },
  { name: 'Cardio Blast', type: 'Cardio', duration: 45, intensity: 'High', date: new Date('2021-07-15') },
  { name: 'Strength Training', type: 'Weights', duration: 60, intensity: 'Medium', date: new Date('2021-07-16') }
]);

// Find all Cardio workouts
const cardioWorkouts = db.getCollection('workouts').find({ type: 'Cardio' });
console.log('Cardio Workouts:', cardioWorkouts);

// Update the duration of "Morning Yoga" to 45 minutes
db.getCollection('workouts').updateOne(
  { name: 'Morning Yoga' },
  { $set: { duration: 45 } }
);

// Delete a workout named "Strength Training"
db.getCollection('workouts').deleteOne({ name: 'Strength Training' });

// Aggregate workouts by type and calculate average duration
db.getCollection('workouts').aggregate([
  { $group: { _id: '$type', averageDuration: { $avg: '$duration' } } }
]);
